import BgItp from "./src/assets/image/itp.jpg";
import logohmti from "./src/assets/image/HMTI.png"
import Pendidikan from "./src/assets/image/Pendidikan.jpeg"
import Penelitian from "./src/assets/image/penelitian.JPEG"
import Masyarakat from "./src/assets/image/masyarakat.JPEG"
 const DataIMG = {
    BgItp,
    logohmti,
    Pendidikan,
    Penelitian,
    Masyarakat, 
 };

 export default DataIMG;