import DataIMG from '../../data'

function Pengabdian() {
  return (
    <section id="pengabdian" className="py-10">
      <div className="container px-0">
        <div className="flex flex-col md:flex-row items-center">
          <div className="flex flex-col text-start text-[1.5rem] px-10 gap-2 py-5 md:w-1/2">
            <h6 className="text-[3rem] text-start py-2">
              Pengabdian Masyarakat
            </h6>
            <p>
              Mengabdi kepada masyarakat adalah hilirisasi dari penerapan pendidikan dan penelitian
              yang dilakukan oleh Institut Teknologi Padang (ITP). Mahasiswa dan civitas akademika
              ITP melaksanakan pengabdian kepada masyarakat dengan mengunjungi langsung lokasi
              pelaksanaan dan memberikan inovasi kepada masyarakat sesuai dengan kebutuhan dan
              kondisi di daerah tersebut. Teknologi Tepat Guna (TTG) yang diciptakan oleh ITP
              menjadi salah satu bukti penerapan tri dharma perguruan tinggi yang berasal dari
              mahasiswa dan dosen ITP dan bermuara ke masyarakat.
            </p>
          </div>

          <div
            className="mt-10 md:mt-0 rounded-2xl w-full md:w-1/2 h-[60vh] bg-cover bg-center"
            style={{ backgroundImage: `url(${DataIMG.Masyarakat})` }}
          ></div>
        </div>
      </div>
    </section>
  )
}

export default Pengabdian
