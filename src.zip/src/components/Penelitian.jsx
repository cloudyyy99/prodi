import DataIMG from "../../data"



function Praktek(){
        return(<>
        <div className="container py-0 px-0">
    <div className="flex-row px-0 items-center flex">
        <div className="flex md-10 mr-50 ml-20" >
    <div className="mt-10 rounded-2xl w-1/2 pr-80 px-50 py-50 h-[60vh] bg-cover" style={{backgroundImage: `url(${DataIMG.Penelitian})`,}}>
</div>                  
<p className="flex-col text-start text-[1.5rem] px-10 gap-2 py-5">
<h6 className="text-[4rem] text-start py-2">Penelitian</h6>
  Melaksanakan Tri Dharma Perguruan Tinggi merupakan prioritas Institut Teknologi Padang (ITP) dalam melahirkan Sumber Daya Manusia (SDM) yang cerdas dan mengimplementasikan ilmu pengetahuan untuk kemajuan bangsa, salah satunya melalui penelitian.Dengan melakukan penelitian inovatif secara kontinue, Institut Teknologi Padang (ITP) berhasil meraih tiga kategori prestasi membanggakan di bidang penelitian dari Lembaga Layanan Pendidikan Tinggi (LLDIKTI) Wilayah X.                     
 </p>
</div>
</div>
</div>

        </>)

}export default Praktek