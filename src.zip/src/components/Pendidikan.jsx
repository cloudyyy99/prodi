
import DataIMG from '../../data'

function Pendidikan() {
  return (
   <div className="container py-0 px-0">
    <div className="flex-row px-0 items-center flex">
        <div className="flex md-10 mr-50 ml-20" >
<p className="flex-col text-start text-[1.5rem] px-10 gap-2 py-5">
<h6 className="text-[4rem] text-start py-2">Pendidikan</h6>
 Menuju World Class University 2040, Institut Teknologi Padang (ITP) terus berupaya meningkatkan mutu pendidikan, penelitian yang inovatif, dan diseminasi ilmu pengetahuan dan teknologi.&nbsp;Sebagai salah satu pelopor penerapan program kurikulum Merdeka Belajar Kampus Merdeka (MBKM), ITP juga berkonsentrasi dalam menyiapkan lulusan yang berkompeten di dunia kerja serta memiliki wawasan dan skill yang luas untuk menjawab tantangan Revolusi Industri 4.0 dan Society 5.0.  
 </p>
    <div className="mt-10 rounded-2xl w-1/2 pr-80 px-50 py-50 h-[60vh] bg-cover" style={{backgroundImage: `url(${DataIMG.Pendidikan})`,}}>
</div>                  
</div>
</div>
</div>

  )
}

export default Pendidikan