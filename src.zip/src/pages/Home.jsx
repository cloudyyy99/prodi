import { Navbar } from "../components/Navbar";
import { ThemeToggle } from "../components/ThemeToggle";
import { HeroSection } from "../components/HeroSection";
import { Footer } from "../components/Footer";

import Pendidikan from "../components/Pendidikan";
import Praktek from "../components/Penelitian";
import Pengabdian from "../components/Pengabdian";



export const Home = () => {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      
      <ThemeToggle />
      <Navbar />
      <main>
        <HeroSection />
        <Pendidikan />
        <Praktek />
        <Pengabdian />
        
      </main>

      <Footer />
    </div>
  );
};
