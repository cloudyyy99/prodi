export function VisiMisi() {
  return (
    <section id="visi-misi" className="p-8">
      <h1 className="text-3xl font-bold">Visi dan Misi</h1>
      <p>Visi dan misi Program Studi Teknik Informatika.</p>
    </section>
  );
}
