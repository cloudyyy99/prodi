export function Kurikulum() {
  return (
    <section id="kurikulum" className="p-8">
      <h1 className="text-3xl font-bold">Kurikulum</h1>
      <p>Struktur kurikulum program studi Teknik Informatika.</p>
    </section>
  );
}
