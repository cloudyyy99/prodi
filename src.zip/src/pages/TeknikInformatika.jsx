export function TeknikInformatika() {
  return (
    <section id="teknik-informatika" className="p-8">
      <h1 className="text-3xl font-bold">Teknik Informatika</h1>
      <p>Informasi tentang Program Studi Teknik Informatika.</p>
    </section>
  );
}
