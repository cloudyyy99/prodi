export function Dosen() {
  return (
    <section id="dosen" className="p-8">
      <h1 className="text-3xl font-bold">Dosen</h1>
      <p>Daftar dosen pengajar di Program Studi Teknik Informatika.</p>
    </section>
  );
}
