export function ProfilLulusan() {
  return (
    <section id="profil-lulusan" className="p-8">
      <h1 className="text-3xl font-bold">Profil Lulusan</h1>
      <p>Profil lulusan dan prospek kerja alumni.</p>
    </section>
  );
}
