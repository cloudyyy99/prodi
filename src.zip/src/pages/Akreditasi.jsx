export function Akreditasi() {
  return (
    <section id="akreditasi" className="p-8">
      <h1 className="text-3xl font-bold">Akreditasi</h1>
      <p>Informasi akreditasi program studi.</p>
    </section>
  );
}
