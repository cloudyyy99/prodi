import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Home } from "./pages/Home";
import { TeknikInformatika } from "./pages/TeknikInformatika";
import { VisiMisi } from "./pages/VisiMisi";
import { ProfilLulusan } from "./pages/ProfilLulusan";
import { Dosen } from "./pages/Dosen";
import { Akreditasi } from "./pages/Akreditasi";
import { Kurikulum } from "./pages/Kurikulum";
import { Toaster } from "@/components/ui/toaster";
import { Navbar } from "./components/Navbar";

function App() {
  return (
    <>
      <Toaster />
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route index element={<Home />} />
          <Route path="/TeknikInformatika" element={<TeknikInformatika />} />
          <Route path="/VisiMisi" element={<VisiMisi />} />
          <Route path="/ProfilLulusan" element={<ProfilLulusan />} />
          <Route path="/Dosen" element={<Dosen />} />
          <Route path="/Akreditasi" element={<Akreditasi />} />
          <Route path="/Kurikulum" element={<Kurikulum />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
