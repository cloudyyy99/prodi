import { useState } from 'react';
import Navbar from './components/Navbar';
import Tentang from './components/Tentang';
import VisiMisi from './components/VisiMisi';
import Akreditasi from './components/Akreditasi';
import ProfilKelulusan from './components/ProfilKelulusan';
import Kurikulum from './components/Kurikulum';
import './index.css';

const components = {
  'tentang': <Tentang />, 
  'visi-misi': <VisiMisi />, 
  'akreditasi': <Akreditasi />, 
  'profil-kelulusan': <ProfilKelulusan />, 
  'kurikulum': <Kurikulum />, 
};

export default function InformatikaWeb() {
  const [active, setActive] = useState('tentang');

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <Navbar active={active} setActive={setActive} />
      <main className="p-6 max-w-3xl mx-auto bg-white mt-6 rounded shadow">
        {components[active]}
      </main>
    </div>
  );
}